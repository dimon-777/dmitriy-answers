const { Given, When, Then, setDefaultTimeout, AfterAll, BeforeAll } = require('cucumber');
const { Builder, Browser, Kye, Util, WebDriver, By, WebElement, assert } = require("selenium-webdriver");
const { chrome, Options } = require("selenium-webdriver/chrome");

setDefaultTimeout(60 * 1000);
const option = new Options();
option.addArguments("--ignore-certificate-errors");
option.addArguments("--ignore-ssl-errors");
const browser = new Builder().forBrowser('chrome').setChromeOptions(option).build();

AfterAll(() => {
  
  browser.close();
})

Given('I navigate to {string} page', async function (string) {
  await browser.get(string);
});


When('I search for product', async function () {
  const we = await browser.findElement(By.xpath("//input[@id='search_query_top']"));
  we.click();
  we.sendKeys("Printed Chiffon Dress");
  (await browser.findElement(By.xpath("//header/div[3]/div[1]/div[1]/div[2]/form[1]/button[1]"))).click()

});

Then('I select a product', async function () {
  (await browser.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/h5[1]/a[1]"))).click()

});

When('I select a different from standard', async function () {
  (await browser.findElement(By.xpath("//option[contains(text(),'M')]"))).click();
  (await browser.findElement(By.xpath("//a[@id='color_15']"))).click();
});
Then('I add it to a cart', async function () {
  (await browser.findElement(By.xpath("//span[contains(text(),'Add to cart')]"))).click();
  await browser.sleep(5000);
  const text = await (await browser.findElement(By.xpath("//body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/h2[1]"))).getText();
  if("Product successfully added to your shopping cart" !== text) {
    throw Error("Text is not the same: " + text);
  }
});