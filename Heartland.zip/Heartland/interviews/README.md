# Heartland Retail Interviews
Use this repository to submit source code for applicants to Heartland Retail. The instructions should have been recieved by email. Complete the task/s given according to those instructions and submit your solutions here.

### How to submit
- Clone the repo
- Create a branch with the format of your name, followed by a forward slash, then the word answers. E.G. {your_name_here}/answers
- Add your source code & push your local branch
- Create a PR from your branch into master

Thank you!